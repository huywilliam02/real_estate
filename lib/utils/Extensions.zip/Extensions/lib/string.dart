import 'dart:developer' as d;

import 'package:ebroker/exports/main_export.dart';

extension S on String {
  void get logg {
    if (Constant.terminalLogMode == "debug") {
      d.log(this);
    } else {
      print(this);
    }
  }

  void log([String? name]) {
    if (Constant.terminalLogMode == "debug") {
      d.log(this, name: name ?? "");
    } else {
      print("[${name ?? "log"}]: $this");
    }
  }
}

extension OB on Object {
  void get logg {
    if (Constant.terminalLogMode == "debug") {
      d.log(toString());
    } else {
      print("$this");
    }
  }

  void log([String? name]) {
    if (Constant.terminalLogMode == "debug") {
      d.log(toString(), name: name ?? "");
    } else {
      print("[${name ?? "log"}]: $this");
    }
  }
}
